// App.jsx
import React from "react";
import { Button } from "@nextui-org/react";
import "./App.css";
import LoginPage from "./pages/login";

export default function App() {
  return (
    <div className="App">
        <LoginPage/>
    </div>
  );
}
