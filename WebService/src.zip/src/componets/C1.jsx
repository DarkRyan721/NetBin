export default C1

function C1 (value)
{
    return (<div>
        <h1>
            Hola world {value}
        </h1>
    </div>)
}